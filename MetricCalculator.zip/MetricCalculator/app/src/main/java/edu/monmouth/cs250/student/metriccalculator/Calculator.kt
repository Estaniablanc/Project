package edu.monmouth.cs250.student.metriccalculator

class Calculator {
    private var mode = Unit.Temperature
    private val temperatureOffset = 32.0
    private val temperatureConvertionFactor = 5.0/9.0
    private val lenghtConvertionFactor = 1.60934
    private val massConversionFactor = 0.453592
    private val volumeConversionFactor = 3.78541

    public fun setMode (selectedMode: Unit) {
        mode = selectedMode
    }
    public fun convert (inputValue: Double): Double{

        var result = 0.0
        when(mode){
            Unit.Temperature->
                result = (inputValue - temperatureOffset) * temperatureConvertionFactor
            Unit.Lenght ->
                result = inputValue * lenghtConvertionFactor
            Unit.Mass ->
                result = inputValue * massConversionFactor
            Unit.Volume->
                result = inputValue * volumeConversionFactor
        }
        return result
    }

}
