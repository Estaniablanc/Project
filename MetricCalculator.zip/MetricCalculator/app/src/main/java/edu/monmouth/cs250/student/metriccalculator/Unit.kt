package edu.monmouth.cs250.student.metriccalculator

enum class Unit {
    Temperature,
    Lenght,
    Mass,
    Volume
}